"""RICOLMC-DDF numerical verification. Pure arithmetic checks of claims in
s_9887, s_9896, s_urmd, s_9915. Run: python3 ricolmc_checks.py"""
import math, json, itertools, random
from collections import deque

R = []
def check(tid, claim, ok, value):
    R.append(dict(id=tid, claim=claim, result="PASS" if ok else "FAIL", value=value))

def bfs_counts(moves, start=(0, 0, 0), kmax=5):
    seen = {start}; frontier = {start}; out = []
    for _ in range(kmax):
        frontier = {m for s in frontier for m in moves(s)} - seen
        seen |= frontier; out.append(len(seen))
    return out

def tri_moves(s):
    h, d, l = s
    return [((h+1) % 4, d, l), ((h-1) % 4, d, l), (h, (d+1) % 3, l),
            (h, (d-1) % 3, l), (h, d, l ^ 1)]

def run():
    c = 2.99792458e8
    # F1
    vals = [60**n for n in (1e-1, 1e-3, 1e-6, 0.0)]
    check("F1", "60^n -> 1 as n -> 0; P*60^n -> P (not suppressed)",
          abs(vals[-1]-1) < 1e-15 and abs(vals[-2]-1) < 1e-5 and all(v >= 1 for v in vals),
          "60^0.1=%.4f, 60^1e-6=%.7f, 60^0=1" % (vals[0], vals[2]))
    check("F1b", "for n>0, 60^n grows (no compression)", 60**2 > 60**1 > 60**0.5 > 1, "60^1=60, 60^2=3600")
    # F2/F15 units, exponent vectors (kg, m, s)
    J = (1, 2, -2); Jm3 = (1, -1, -2)
    add = lambda a, b: tuple(x+y for x, y in zip(a, b))
    check("F15", "J/m^3 x m^3 x dimensionless dmu45 = J", add(Jm3, (0, 3, 0)) == J, "kg m^2 s^-2")
    check("F15b", "J/m^3 x m^5 = J m^2, not J (published measure rejected)",
          add(Jm3, (0, 5, 0)) == (1, 4, -2) != J, "kg m^4 s^-2 = J m^2")
    W = (1, 2, -3)
    check("F2", "power (W) not addable to J/m^3", W != Jm3, "W = kg m^2 s^-3")
    # F16
    rho1, T4, P4, n = 1.0e3, 4.0e16, 2.0e12, 1
    rc2 = rho1*c**2; perp = T4 + P4*60**n; EV = rc2 + perp; share = perp/EV
    check("F16", "E/V = 8.992e19 J/m^3, perpetual share 0.045% (inputs URMD A.4)",
          abs(EV/8.992e19-1) < 1e-4 and abs(share*100-0.045) < 5e-4,
          "rho c^2=%.4e, E/V=%.4e, share=%.4f%%" % (rc2, EV, share*100))
    check("F16b", "published total 9.004e10 < its own term 4e16 (inconsistent)", 9.004e10 < 4.0e16, "true")
    # F8/F17
    CO = math.sqrt(2880/4)
    check("F17", "C_Omega = sqrt(720) = 26.833; sqrt(2880) = 2 C_Omega = 53.666",
          abs(CO-26.833) < 1e-3 and abs(math.sqrt(2880)-2*CO) < 1e-12, "%.4f, %.4f" % (CO, math.sqrt(2880)))
    check("F8", "720 = 6! ; 2880 = 60*48 = 2^6*3^2*5", 720 == math.factorial(6) and 2880 == 60*48 == 2**6*9*5, "ok")
    # Pi2880
    nf = 2880-5+1
    rows = {r: nf*math.log10(r) for r in (0.375, math.exp(-1), 59/60, 1.0, 1.001)}
    check("PI1", "2876 factors for l=5..2880", nf == 2876, nf)
    check("PI2", "log10 Pi2880 at r=0.375 is -1225.09", abs(rows[0.375]+1225.09) < 0.01, "%.3f" % rows[0.375])
    check("PI3", "r=1/e: -1249.03; 59/60: -20.99; 1.001: +1.248",
          abs(rows[math.exp(-1)]+1249.03) < 0.01 and abs(rows[59/60]+20.99) < 0.01 and abs(rows[1.001]-1.248) < 0.001,
          "%.2f, %.2f, %.3f" % (rows[math.exp(-1)], rows[59/60], rows[1.001]))
    nstar = -rows[0.375]/math.log10(60)
    check("PI4", "60^n compensates Pi2880 only for n >= 689", 688 < nstar < 690, "%.1f" % nstar)
    check("PI5", "60^18.86 = 10^33.54; Pi*60^18.86 = 10^-1191.6",
          abs(18.86*math.log10(60)-33.54) < 0.01 and abs(rows[0.375]+18.86*math.log10(60)+1191.6) < 0.1,
          "%.2f" % (rows[0.375]+18.86*math.log10(60)))
    w2875 = 2875*math.log10(0.375)
    check("PI6", "W = w^2875 (or w^2876 as published) ~ 1e-1225", round(w2875) == -1225 or round(rows[0.375]) == -1225,
          "2875: %.2f, 2876: %.2f" % (w2875, rows[0.375]))
    casc = [256, 96, 32, 7, 3, 1]
    check("COL1", "Sigmatics cascade strictly decreasing, so not lossless", all(a > b for a, b in zip(casc, casc[1:])), casc)
    pr = (1/256)**(1/2876); gm = (1/256)**(1/5)
    check("COL2", "uniform per-step ratio 0.99807 (exp -0.00193); 5-step geometric mean 0.330 (O31 dual model)",
          abs(pr-0.99807) < 1e-5 and abs(math.log(pr)+0.00193) < 1e-5 and abs(gm-0.330) < 1e-3,
          "%.5f, %.5f, %.3f; log10 W gap vs 0.375: %.0f" % (pr, math.log(pr), gm, 2876*math.log10(pr)-rows[0.375]))
    # Triality
    K = list(itertools.product(range(4), range(3), range(8)))
    orbT = {frozenset((h, (d+k) % 3, l) for k in range(3)) for h, d, l in K}
    check("TRI1", "K/<T> has 32 orbits", len(orbT) == 32, len(orbT))
    o = lambda h, l: 8*h+l
    ok = all(o((h+3) % 4, l) == (o(h, l)+24) % 32 for h in range(4) for l in range(8))
    cyc = {frozenset(o((h+k) % 4, l) for k in range(4)) for h in range(4) for l in range(8)}
    check("TRI2", "R gives eight 4-cycles; R^3 = shift +24 mod 32", ok and len(cyc) == 8 and all(len(x) == 4 for x in cyc), len(cyc))
    G = set()
    for s in K:
        orb = set(); q = deque([s])
        while q:
            x = q.popleft()
            if x in orb: continue
            orb.add(x); q.extend(tri_moves(x))
        G.add(frozenset(orb))
    check("TRI3", "<R,T,M> orbits: 4 of size 24", len(G) == 4 and all(len(g) == 24 for g in G), len(G))
    seq = bfs_counts(tri_moves)
    check("TRI4", "reachability 6,15,22,24,24 (published 4,9,16,24,32 NOT reproduced)",
          seq == [6, 15, 22, 24, 24] and seq != [4, 9, 16, 24, 32], seq)
    # Gate (abstract toy, no glyph semantics, O12 untouched)
    random.seed(0); X = range(20); ok = True
    for _ in range(200):
        maps = [{x: (x if random.random() < .5 else random.choice(X)) for x in X} for _ in range(6)]
        comp = lambda x: maps[0][maps[1][maps[2][maps[3][maps[4][maps[5][x]]]]]]
        inter = {x for x in X if all(m[x] == x for m in maps)}
        ok &= inter <= {x for x in X if comp(x) == x}
    check("GATE", "toy: common fixed points of 6 abstract maps are fixed by their composition", ok,
          "200 random trials on |X|=20; glyph semantics OPEN (O9, O12)")
    # Horizon / facets
    tab = {6: 48.19, 12: 33.56, 20: 25.84, 60: 14.84, 2880: 2.135, 11520: 1.068, 8294400: 0.0398}
    ok = all(abs(math.degrees(math.acos(1-2/N))-v)/v < 2e-3 for N, v in tab.items())
    check("HOR1", "facet table theta_N = arccos(1-2/N) matches all 7 rows", ok,
          "2880 -> %.3f deg, %.1f arcmin" % (math.degrees(math.acos(1-2/2880)), 60*math.degrees(math.acos(1-2/2880))))
    check("HOR2", "h/R = 2/N: 2880 -> 6.94e-4", abs(2/2880-6.94e-4) < 1e-6, "%.3e" % (2/2880))
    ea = math.radians(1/60); nsil = 0.2/ea
    check("HOR3", "N_H^sil = 2R/(d eps) ~ 688 for R=0.1, d=1, 1 arcmin", round(nsil) == 688, "%.1f" % nsil)
    sh = {e: 2/(1-math.cos(math.radians(e))) for e in (1, 2, 0.5)}
    check("HOR4", "N_H^shade: 1deg 13132, 2deg 3283, 0.5deg 52525",
          [round(sh[1]), round(sh[2]), round(sh[0.5])] == [13132, 3283, 52525], [round(v) for v in sh.values()])
    check("HOR5", "polyhedra: dodeca V-E+F=20-30+12=2, icosa 12-30+20=2", 20-30+12 == 2 and 12-30+20 == 2, 2)
    # URMD correspondences
    check("URMD1", "60^18.86 = 3.4e33; 60^(18.86/32)=11.17", abs(60**18.86/3.4e33-1) < 0.02 and abs(60**(18.86/32)-11.17) < 0.01,
          "%.3e, %.3f" % (60**18.86, 60**(18.86/32)))
    b = 96*math.log2(96)
    check("URMD2", "2876*18.86/32=1695.0; 96 log2 96=632.2; 632/2048=30.9%",
          abs(2876*18.86/32-1695.0) < 0.1 and abs(b-632.2) < 0.1 and abs(632/2048-0.309) < 1e-3,
          "%.2f, %.2f, %.2f%%" % (2876*18.86/32, b, 63200/2048))
    check("URMD3", "3/8 vs 1/e (1.9%) and 1/phi^2 (1.8%); 96/256 = 3/8",
          96/256 == .375 and round(100*(.375/math.exp(-1)-1), 1) == 1.9 and round(100*(1-.375*((1+5**.5)/2)**2), 1) == 1.8,
          "%.2f%%, %.2f%%" % (100*(.375/math.exp(-1)-1), 100*(1-.375*((1+5**.5)/2)**2)))
    check("URMD4", "choke chain constant 2700*960*90 = 2.3e8", abs(2700*960*90/2.3e8-1) < 0.02, 2700*960*90)
    check("URMD5", "simulated 60^k table 1,60,3600,216000", [60**k for k in range(4)] == [1, 60, 3600, 216000], "definition only")
    return R

if __name__ == "__main__":
    res = run()
    for r in res: print("%-6s %-4s %s | %s" % (r["id"], r["result"], r["claim"], r["value"]))
    json.dump(res, open("../results.json", "w"), indent=1, default=str)
    print("%d/%d PASS" % (sum(r["result"] == "PASS" for r in res), len(res)))

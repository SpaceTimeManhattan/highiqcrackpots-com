from ricolmc_checks import run
def test_all():
    bad = [r for r in run() if r["result"] != "PASS"]
    assert not bad, bad

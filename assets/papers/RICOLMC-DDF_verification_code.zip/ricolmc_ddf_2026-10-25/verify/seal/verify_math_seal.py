#!/usr/bin/env python3
import json, hashlib, math, sys
from pathlib import Path
sys.path.insert(0, "/workspace/glyph9")
from glyph15 import chk_damm, verify, encode, N
seal = json.loads(Path(__file__).with_name("seal.json").read_text())
meta = json.loads(Path(__file__).with_name("math_seal.json").read_text())
stream = seal["core_seal"]
sha = seal["commitment_sha256"]
stream_s = ".".join(map(str, stream))

def glyph_path_fingerprint(g):
    pts = []
    for k in range(16):
        t = k / 15
        x = math.cos(2 * math.pi * (g + 1) * t)
        y = math.sin(2 * math.pi * ((g % 5) + 1) * t)
        pts.append(f"{x:.12f},{y:.12f}")
    return "|".join(pts)

geo = "||".join(glyph_path_fingerprint(g) for g in stream)
layer_a = stream_s + "|gate0|2024-11-17|damm:2a+b_mod15"
layer_b = hashlib.sha256((layer_a + "||GEO||" + geo).encode()).hexdigest()
double = hashlib.sha256((sha + "|" + layer_b).encode()).hexdigest()
outer_seal = encode([int(c, 16) % N for c in double])
gate = chk_damm([2, 0, 2, 4, 1, 1, 1, 7])[0]
checks = {
    "date_gate0": gate == 0,
    "layer_a_verify": verify(stream),
    "layer_b_match": layer_b == meta["layer_b_geo_sha256"],
    "double_match": double == meta["double_sha256"],
    "outer_match": outer_seal == meta["outer_damm_seal"],
    "outer_verify": verify(outer_seal),
}
ok = all(checks.values())
print(json.dumps(checks, indent=2))
print("PASS" if ok else "FAIL")
mut = list(stream); mut[3] = (mut[3] + 1) % N
geo2 = "||".join(glyph_path_fingerprint(g) for g in mut)
layer_b2 = hashlib.sha256((".".join(map(str, mut)) + "|gate0|2024-11-17|damm:2a+b_mod15||GEO||" + geo2).encode()).hexdigest()
print("mutation_detected", layer_b2 != layer_b)
sys.exit(0 if ok else 1)

"""15-glyph coding system. Positions 1..15 (internal values 0..14).
1-9 arrow glyphs, 10-15 prime atoms Orr Na Ka Sa Mu Wa. 60 codes = 4 rows x 15.
Messages end with END mark (Pi with small circle), which is not a data glyph."""
NAMES = ["A1","A2","A3","A4","A5","A6","A7","A8","A9","Orr","Na","Ka","Sa","Mu","Wa"]
END = "PI°"
N = 15

def code_number(row, pos):
    assert 1 <= row <= 4 and 1 <= pos <= 15
    return (row - 1) * 15 + pos

def code_decode(num):
    assert 1 <= num <= 60
    return (num - 1) // 15 + 1, (num - 1) % 15 + 1

# ---- check schemes: operate on value lists (0..14), return check value ----
def chk_none(v): return []
def chk_sum(v): return [sum(v) % N]
UNIT_W = (1, 2)  # alternating weights, both units mod 15
def _w(i): return UNIT_W[i % 2]
def chk_wsum(v): return [sum(_w(i) * x for i, x in enumerate(v)) % N]
def chk_posw(v): return [sum((i + 1) * x for i, x in enumerate(v)) % N]  # naive weights i (not all units)
def chk_two(v): return [sum(v) % N, sum(_w(i) * x for i, x in enumerate(v)) % N]

def _damm_op(a, b): return (2 * a + b) % N  # latin square; a-1=1 unit, b=1: anti-symmetric
def damm_interim(v):
    s = 0
    for x in v: s = _damm_op(s, x)
    return s
def chk_damm(v):
    s = damm_interim(v)
    for c in range(N):
        if _damm_op(s, c) == 0: return [c]
SCHEMES = {"none": (chk_none, 0), "sum15": (chk_sum, 1), "posw15": (chk_posw, 1),
           "wsum15(1,2)": (chk_wsum, 1), "two-glyph": (chk_two, 2), "damm15": (chk_damm, 1)}

def encode(positions, scheme="damm15"):
    """positions: list of 1..15. returns list of positions incl. check glyph(s), plus END implied."""
    v = [p - 1 for p in positions]
    return [c + 1 for c in positions] if False else positions + [c + 1 for c in SCHEMES[scheme][0](v)]

def verify(msg, scheme="damm15"):
    k = SCHEMES[scheme][1]
    if len(msg) < k: return False
    data = msg[:len(msg) - k]
    return encode(data, scheme) == list(msg)

def decode(msg, scheme="damm15"):
    if not verify(msg, scheme): raise ValueError("check failed")
    return list(msg[:len(msg) - SCHEMES[scheme][1]])

def to_text(msg): return " ".join(NAMES[p - 1] for p in msg) + " " + END
def from_text(s):
    t = s.split()
    assert t[-1] == END
    return [NAMES.index(x) + 1 for x in t[:-1]]

def int_to_glyphs(n):
    d = []
    while True:
        d.append(n % 15 + 1); n //= 15
        if n == 0: break
    return d[::-1]
def glyphs_to_int(g):
    n = 0
    for p in g: n = n * 15 + p - 1
    return n

"""Independent re-implementation (not importing verify/code) of the finite and numerical
claims audited under Rev8 P07. Prints each result; exit code 1 on any mismatch."""
import itertools, math, sys
from collections import deque
bad = []
def rep(name, ok, val):
    print(f"{'OK  ' if ok else 'FAIL'} {name}: {val}")
    if not ok: bad.append(name)

K = [(h, d, l) for h in range(4) for d in range(3) for l in range(8)]
rep("|Z4xZ3xZ8|", len(K) == 96, len(K))
# T: d -> d+1 (order 3). Orbits of <T>
seen, orbits = set(), 0
for s in K:
    if s in seen: continue
    orbits += 1
    x = s
    for _ in range(3): seen.add(x); x = (x[0], (x[1]+1) % 3, x[2])
rep("<T> orbits", orbits == 32, orbits)
# R: h -> h+1 on the 32 orbit labels 8h+l; cycles
lab = lambda h, l: 8*h + l
perm = {lab(h, l): lab((h+1) % 4, l) for h in range(4) for l in range(8)}
cyc, vis = [], set()
for v in range(32):
    if v in vis: continue
    c = [v]; vis.add(v); w = perm[v]
    while w != v: c.append(w); vis.add(w); w = perm[w]
    cyc.append(len(c))
rep("R cycle type on 32 labels", cyc == [4]*8, f"{len(cyc)} cycles of lengths {sorted(set(cyc))}")
rep("R^3 = +24 mod 32", all(perm[perm[perm[v]]] == (v+24) % 32 for v in range(32)), "checked 32 labels")
# reachability under generators h+-1, d+-1, l xor 1 from (0,0,0)
def nb(s):
    h, d, l = s
    return {((h+1) % 4, d, l), ((h-1) % 4, d, l), (h, (d+1) % 3, l), (h, (d-1) % 3, l), (h, d, l ^ 1)}
seenR, fr, seq = {(0, 0, 0)}, {(0, 0, 0)}, []
for _ in range(5):
    fr = {m for s in fr for m in nb(s)} - seenR; seenR |= fr; seq.append(len(seenR))
rep("reachability (cumulative, k=1..5)", seq == [6, 15, 22, 24, 24], seq)
rep("published 4,9,16,24,32 reproduced?", seq != [4, 9, 16, 24, 32], "NO: mismatch preserved (published claim FAILED)")
# thinning
l10 = 2876*math.log10(0.375)
rep("0.375^2876 = 10^x", abs(l10 + 1225.09) < 0.005, f"x = {l10:.4f}")
# exact rational check of exponent bracket: 10^-1226 < (3/8)^2876 < 10^-1225
from fractions import Fraction
# use integer logs: compare 3^2876 * 10^1226 vs 8^2876
rep("10^-1226 < (3/8)^2876 < 10^-1225 (exact integers)",
    3**2876 * 10**1226 > 8**2876 > 3**2876 * 10**1225, "exact big-integer comparison")
# limit
vals = [60**(10.0**-k) for k in (1, 3, 6, 9, 12)]
rep("60^n -> 1 as n -> 0", abs(vals[-1]-1) < 1e-10 and all(v > 1 for v in vals), [f"{v:.12f}" for v in vals])
rep("sqrt(720)", abs(math.sqrt(720) - 26.8328) < 5e-5, f"{math.sqrt(720):.6f}  (square = {math.sqrt(720)**2:.6f}, distinct from root)")
# horizon numbers cited in verify suite
th = math.degrees(math.acos(1 - 2/2880))
rep("theta_2880 = arccos(1-2/2880)", abs(th - 2.135) < 1e-3, f"{th:.4f} deg = {60*th:.2f} arcmin")
rep("h/R = 2/2880", abs(2/2880 - 6.944e-4) < 1e-6, f"{2/2880:.4e}")
rep("N_H^sil = 0.2/(1 arcmin)", round(0.2/math.radians(1/60)) == 688, f"{0.2/math.radians(1/60):.2f}")
sh = [2/(1-math.cos(math.radians(e))) for e in (1, 2, 0.5)]
rep("N_H^shade 1,2,0.5 deg", [round(x) for x in sh] == [13132, 3283, 52525], [round(x) for x in sh])
rep("60^n compensation n*", 688 < -l10/math.log10(60) < 690, f"{-l10/math.log10(60):.2f}")
print(f"\n{'ALL REPRODUCED' if not bad else 'MISMATCHES: ' + ', '.join(bad)}")
sys.exit(1 if bad else 0)

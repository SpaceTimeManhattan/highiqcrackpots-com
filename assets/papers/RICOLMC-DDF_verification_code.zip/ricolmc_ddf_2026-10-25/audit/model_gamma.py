"""RICOLMC-DDF Rev8 finite model instance D0 (audit P01-P06).
Configuration space X = Z4 x Z3 x Z8 (triality coordinates h,d,l written a,b,c).
Six explicit operators X->X, Gamma = Orr o Na o Ka o Sa o Mu o Wa (Wa applied first).
Extended 2880-address space X2880 = X x Z30 (96*30 = 2880); five-coordinate
operational space X5 = Z4 x Z3 x Z8 x Z5 x Z6 (4*3*8*5*6 = 2880).
MODEL INSTANCE ONLY: not the physical plate, not M_2880 as a manifold."""
import itertools, json, hashlib

X = list(itertools.product(range(4), range(3), range(8)))
RHO0_J_PER_M3 = 1.0   # model density unit
V_M3 = 1.0            # model cell volume

def Wa(x):  a,b,c = x; return (a, b, 2*(c//2))                    # cadence: l even
def Mu(x):  a,b,c = x; return (a, a % 3, c)                        # power: d = h mod 3
def Sa(x):  a,b,c = x; return (a, b, (c % 4) + 4*(a % 2))          # stress: l high bit = h parity
def Ka(x):  a,b,c = x; return (min(a, 2), b, c)                    # condense: h <= 2
def Na(x):  a,b,c = x; return (a, b, 4*(c//4) + 2*(1 if b else 0) + (c % 2))  # integral: l bit1 = [d!=0]
def sectors(x):
    """DDF sector densities in units of RHO0 (J/m^3): density, dimension, field, cross D x F."""
    a,b,c = x
    return {"D": a+1, "Dim": b+1, "F": c+1, "DxF": a*c}
def E(x):
    """Model SREF: E = V * sum_j rho_j, in joules. Finite sum, 60^n cadence factor at n=0 equals 1."""
    return V_M3 * RHO0_J_PER_M3 * sum(sectors(x).values())
EMAX = 16.0
def Orr(x): return x if E(x) <= EMAX else (0, 0, 0)             # total: energy budget cap

OPS = [("Wa",Wa),("Mu",Mu),("Sa",Sa),("Ka",Ka),("Na",Na),("Orr",Orr)]
def Gamma(x, trace=False):
    steps=[x]
    for _,f in OPS: x=f(x); steps.append(x)
    return (x, steps) if trace else x

# 2880 / 5 layer
def G2880(y): return Gamma(y[:3]) + (y[3],)
def F5(y):    a,b,c,k = y; return (a,b,c,k % 5,k % 6)            # fold to 5 coordinates
def R5(z):    a,b,c,u,v = z; k = next(k for k in range(30) if k%5==u and k%6==v); return (a,b,c,k)  # CRT
def CRT(u,v): return (6*u*1 + 25*v) % 30   # closed form: 6*(6^-1 mod 5=1)*u + 5*(5^-1 mod 6=5)*v
def G5(z):    return Gamma(z[:3]) + z[3:]

def main():
    out = {}
    fix = [x for x in X if Gamma(x)==x]
    common = [x for x in X if all(f(x)==x for _,f in OPS)]
    out["Fix_Gamma_X"] = fix; out["common_fixed"] = common
    out["|X|"]=len(X); out["|Fix|"]=len(fix)
    xa=(2,2,2); xr=(1,1,6)
    out["admit_trace"] = Gamma(xa,True)[1]; out["reject_trace"] = Gamma(xr,True)[1]
    out["reject_example_2"] = Gamma((3,0,5),True)[1]
    out["E(admit)_J"]=E(xa); out["sectors(admit)"]=sectors(xa); out["E(reject)_J"]=E(xr)
    nc = [(n1,n2) for (n1,f1) in OPS for (n2,f2) in OPS if n1<n2 and any(f1(f2(x))!=f2(f1(x)) for x in X)]
    out["noncommuting_pairs"]=nc
    w=(3,0,0); out["SaKa_witness"]={"x":w,"Ka(Sa(x))":Ka(Sa(w)),"Sa(Ka(x))":Sa(Ka(w))}
    # order sensitivity of the composite
    perms = list(itertools.permutations(OPS)); fsizes=set()
    def comp(ops,x):
        for _,f in ops: x=f(x)
        return x
    distinct = {tuple(comp(p,x) for x in X) for p in perms}
    out["distinct_composites_over_720_orders"]=len(distinct)
    out["Gamma_idempotent"]= all(Gamma(Gamma(x))==Gamma(x) for x in X)
    out["image_Gamma_eq_Fix"]= sorted(set(map(Gamma,X)))==sorted(fix)
    Y = [x+(k,) for x in X for k in range(30)]
    out["|X2880|"]=len(Y)
    A = [y for y in Y if G2880(y)==y]; out["|A_Gamma_2880|"]=len(A)
    out["C1_halts_all_A"]= all(isinstance(E(y[:3]),float) for y in A)
    out["C2_commute_all_X2880"]= all(F5(G2880(y))==G5(F5(y)) for y in Y)
    out["C2_admissible_under_reduction"]= all(G5(F5(y))==F5(y) for y in A)
    out["C3_R_F_id_all_X2880"]= all(R5(F5(y))==y for y in Y)
    out["C3_closed_form_CRT_matches"]= all(CRT(u,v)==R5((0,0,0,u,v))[3] for u in range(5) for v in range(6))
    out["F5_bijective"]= len({F5(y) for y in Y})==2880
    out["C4_sum_exact_all_A"]= all(abs(E(y[:3])-sum(sectors(y[:3]).values()))<1e-12 for y in A)
    out["E_values_on_Fix"]={str(x):E(x) for x in fix}
    return out

if __name__=="__main__":
    o=main()
    for k,v in o.items(): print(f"{k}: {v}")
    open("logs/model_gamma.json","w").write(json.dumps(o,indent=1,default=str))

# Reachability on Z4 x Z3 x Z8 under R+-, T+-, M (lowest bit of l)
S={(0,0,0)};out=[]
for k in range(1,8):
    new=set()
    for h,d,l in S:
        for m in [((h+1)%4,d,l),((h-1)%4,d,l),(h,(d+1)%3,l),(h,(d-1)%3,l),(h,d,l^1)]: new.add(m)
    S|=new; out.append(len(S))
print(out)

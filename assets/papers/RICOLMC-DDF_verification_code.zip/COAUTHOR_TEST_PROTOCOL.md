# RICOLMC-DDF coauthor check protocol

**Purpose.** Recipients reproduce the arithmetic / finite checks shipped with the draft. Integrity tooling beyond this pack will be shared later.

## Minimum (~2 min)

1. Open the shared PDF.
2. Unzip the coding handoff; read `RUN.txt`.
3. Run:
   ```bash
   cd ricolmc_ddf_2026-10-25 && python3 verify/code/ricolmc_checks.py
   ```
   Expect the PASS table matching the paper’s verification section.

## Optional

- `python3 -m pytest verify/code/test_ricolmc.py`
- `python3 audit/reproduce_finite.py`
- Search trials: report **both** real trials **and** pruned/covered counts separately. Never one blended number. 999Q/day is stretch/cover, not a laptop quota.

## Reply template

- verify/code: PASS / FAIL
- Real trials (if any): N
- Pruned/covered (if any): M
- Machine: laptop / desktop / cluster
